/**
 * Created by fletcher on 2017-07-02.
 */

/*This feels like cheating*/
/*So, this method doesn't actually work, anyway-- it creates an array, which is then no-longer a string that
can be parsed by JSON.
 */

var dataSet = [
    {
        "Names": "Ross",
        "Company": "Quis Urna Nunc Company",
        "Email": "amet.orci@sagittisDuisgravida.com",
        "Phone": "(855) 152-2097"
    },
    {
        "Names": "Jada",
        "Company": "Pretium Corp.",
        "Email": "lacinia.vitae.sodales@quis.com",
        "Phone": "(580) 169-1471"
    },
    {
        "Names": "Iola",
        "Company": "Duis Limited",
        "Email": "sed.pede@et.org",
        "Phone": "(649) 970-8829"
    },
    {
        "Names": "Jonas",
        "Company": "Ac Associates",
        "Email": "scelerisque.dui.Suspendisse@luctus.co.uk",
        "Phone": "(369) 430-5709"
    },
    {
        "Names": "Norman",
        "Company": "Id Foundation",
        "Email": "mus@In.net",
        "Phone": "(713) 889-8319"
    },
    {
        "Names": "Urielle",
        "Company": "Dolor Quisque Tincidunt Associates",
        "Email": "vitae.purus.gravida@MaurismagnaDuis.co.uk",
        "Phone": "(383) 708-2318"
    },
    {
        "Names": "Hyatt",
        "Company": "Purus Ltd",
        "Email": "Curabitur@molestie.co.uk",
        "Phone": "(723) 704-9914"
    }
];

JSON.
console.log(dataSet[0].Company);
//var jsonText = localStorage.getItem('dataSet.json'); // Does not work.
//console.log(jsonText); // <-- null
var contacts =  JSON.parse(dataSet);
console.log(contacts.contacts.length);
console.log(contacts[1].Company);


